README : WiiSX RX / CubeSX RX
Beta 3.3

LICENSE:
    This software is licensed under the GNU General Public License v2
      which is available at: https://www.gnu.org/licenses/gpl-3.0.html
    This requires any released modifications to be licensed similarly,
      and to have the source available.

QUICK USAGE:
 * Games can be .bin + .cue (Make sure .cue contains _relative_ directory!), a single .bin, .img, or .iso format
 * To install: Extract the contents of WiiSXRX.zip to the root of your SD card
 * For SD/USB: Put games (.bin + .cue or other formats) in the directory named /WiiSXRX/isos (SD / USB)
    All Memory Cards will automatically be placed in /WiiSXRX/saves
	All Savestates will automatically be placed in /WiiSXRX/savestates
 * For DVD media: games may be anywhere on the disc (requires DVDxV2 on Wii)
 * For actual BIOS: Put SCPH1001.BIN in the directory named /WiiSXRX/bios (SD / USB)
 * Load the executable from the HBC or in the loader of your choice
    Once the emulator is running, select 'Load CD', choose the source media, and select the game to load
		(Note: to go up a directory select '..', B will exit the file browser)
 * Select 'Play Game' to play
   You can go back from a game to the emulator menu by pressing a configurable key combination together.
   If you haven't changed it through the settings, the defaults are:
   On a GC pad (START & X), Wii Classic Controller or Pro (HOME), Wiimote (- & +),
   Wii U Pro Controller (HOME), or Wii U Gamepad (HOME)
   Wiimote+Nunchuck (1 & 2), or the Wii's reset button.
		(Note: this must be done to save your game; it will not be done automatically)

Controls:
 * While the Gamecube pad is compatible, a Wii Classic Controller, Wii Classic Controller Pro, or Wii U Pro Controller is recommended.
 * The Wii U Gamepad is also compatible, but only when doing Wii U injections (no, you can't use it on vWii).
 * Controls are fully configurable so any button on your controller can be mapped.
 * The controller configuration screen presents each PSX button and allows you to toggle through sources.
 * There are 4 configuration slots for each type of controller:
   * To load a different, previously saved configuration, select the slot, and click 'Load'
   * After configuring the controls as desired, select the slot, and click 'Save'
   * After saving different configurations to the slots, be sure to save your configs in the input tab of the Settings frame.
 * Clicking 'Next Pad' will cycle through the PSX controllers assigned.
 * There is an option to invert the Y axis of the PSX's analog sticks; by default this is 'Normal Y'.
 * The 'Menu Combo' configuration allows you to select a button combination to return to the menu.

Settings:
 * GENERAL
   * Select CPU core: choose whether to play games with pure
   interpreter (better compatibility) or dynarec (better speed).
   * Select BIOS: choose your own dumped BIOS file source. HLE is for the embedded open source BIOS,
   which will change compatibility, so change between them if a game doesn't run at all with the commercial PSX BIOS.
   Remember to put your own PSX BIOS file (Model SCPH1001 recommended) into the BIOS folder on your drive,
   or you won't be able to select it here and use it. No, different BIOS models DO NOT CHANGE compatibility.
   * Boot through BIOS: boot the games with the Sony PlayStation screen, if you're using an external PSX BIOS.
   * Execute BIOS: boot the PSX BIOS only.
   * Save settings: save all of these settings either SD or USB (to be loaded automatically next time).
 * VIDEO
   * Show FPS: display the framerate in the top-left corner of the screen.
   * Limit FPS: limit the framerate to 59.94 (60 Hz NTSC games) or 50 (50Hz PAL games) when using Auto.
   Off will make it go as far as the console's CPU can push the framerate.
   * Frameskip: allows the emulator to skip some frames to maintain full speed on some games.
   * Screen Ratio: select the aspect ratio of the display; 'Force 16:9' will pillar-box the in-game display.
   * Dithering: set the original PSX console behavior, depending on whether you want to use the feature or not.
   It will create some extra workload on the CPU, so turn it to None, Default or Always at your discretion.
 * INPUT
   * Configure Input: select controllers to use in game.
   * Configure Buttons: enter the controller configuration screen described above.
   * Save button configs: save all of the controller configuration slots to SD or USB.
   * Auto Load slot: Select which slot to automatically be loaded for each type of controller.
 * AUDIO
   * Disable audio: select to mute the sound completely.
   * Disable XA: select to mute XA music or sounds.
   * Disable CDDA: select to mute CD music (Red Book format).
   * Volume: choose to lower or boost the produced sound.
 * SAVES
   * Memcard Save device: Choose where to load and save native game saves.
   * Auto Save Memcards: When enabled, the emulator will automatically load
	 saves from the selected device on game load, and save when returning to
	 the menu or pressing the power button on the console.
   * Save States device: Choose where to load and save save states.
   * Copy Saves: Not yet implemented.
   * Delete Saves: Not yet implemented.

REPORTING ISSUES:
 Report emulator issues to https://github.com/niuus/wiisxrx/issues
 DO NOT report individual game bugs.

CODE:
 Source code can be found here https://github.com/niuus/wiisxrx/

CREDITS:
 * WiiSX RX fork: NiuuS
 * WiiSX RX logo: NiuuS
 * WIISXR fork: mystro256
 * WIISXR logo: iiiGerardoiii
 * General Coder: emu_kidid
 * Graphics & Menu Coder: sepp256
 * Audio & Core Coder: tehpola
 * Artwork: drmr
 * USB 2.0 support: matguitarist
 * LibWiiDRC integration: FIX94
 * https://github.com/FIX94/libwiidrc
 * LibWUPC integration: Daxtsu
 * https://github.com/FIX94/libwupc
 * PSX Multitap: vmartinv
 * https://github.com/vmartinv/wiisxr
 * xjsxjs197 updates from PCSX-ReARMed:
 * https://github.com/xjsxjs197/WiiSXRX_2022/
 * pcsx team http://www.pcsx.net/
 * pcsx-df http://pcsx-df.sourceforge.net/
 * pcsx-r http://pcsxr.codeplex.com/
 * pcsx-revolution https://code.google.com/archive/p/pcsx-revolution/downloads
 * pcsx-ReARMed https://github.com/notaz/pcsx_rearmed
 * pcsx 1.5-test3 mac version by Gil Pederson http://pcsx.gpost.dk/
 * P.E.Op.S. PSX Gpu & SPU http://sourceforge.net/projects/peops/ 
 * franspu
 * CDRMooby
 * CDRISO
 * SSSPSX
 * Compiled using devKitPro
     ( http://sourceforge.net/projects/devkitpro )
 * www.emulatemii.com and https://code.google.com/archive/p/pcsxgc/downloads


RX CHANGELOG FOR THIS BUILD:
++ Beta 3.3 - 20221226:

* gteAVSZ3, gteAVSZ4, gteRTPS, and gteRTPT updates.
* GTE updates.
* Updates to CDrom plugin and new timer, compatibility rise.
* Autofixes for RCnt, dwEmu, pR3000, HWTR
* Cosmetic and QoL updates.

------------------------------------------------------------------------------
READ CAREFULLY:
There are separate builds, one is WiiSXRX-FS and the other one is WiiSXRX-DS. Each one uses a different sound plugin.

WiiSXRX-FS is more recommended for use on the Wii, since it is lighter on resources. It can give you a speed boost that
may vary between 5-15 FPS, depending on the game. Some games may even sound better on this build, compared to -DS.
However, the sound plugin within this build does NOT read Red Book audio (CDDA).

WiiSXRX-DS is more recommended for use on the Wii U's "overclocked mode". Being more accurate, means it is heavier on
the use of the console's resources, which in turn means less FPS on limited systems like the Gamecube and Wii,
hence the recommendation. Some games do sound better or without audio glitches on this build, or even
require it to work fully, compared to -FS. The sound plugin within this build DOES include full
support for Red Book audio (CDDA).
------------------------------------------------------------------------------
Thanks goes to the PCSX / PCSX-df / PCSX-r / PCSX-Revolution / PCSX-ReARMed teams, and xjsxjs197 code adaptations.

3rd party Wii Classic Controller and Pro extended support from RX 2.7 is retained, as well as PS1 / PS2 controller support through the 3rd party Wiimote adapter.

Experimental builds with PSX Multitap support also available. Compatible titles tested are included on a TXT inside the respective .zip

Find a growing list of new playable and tested games on the second post of the official WiiSXRX thread, here:
https://gbatemp.net/threads/wiisx-rx-a-new-fork.570252/


FULL RX CHANGELOG:
++ Beta 3.2 - 20221027:

* CDDA is now available for use. Check the details below about the two new builds.
* Reduced loading time.
* Updates to CDrom plugin and new timer, compatibility rise.
* CDrom speedup.
* GTE updates.

++ Beta 3.1 - 20221016:

* Updates to CDrom plugin, compatibility rise.
* CDrom speedup.
* GTE updates.

Thanks goes to the PCSX / PCSX-df / PCSX-r / PCSX-Revolution / PCSX-ReARMed teams, and xjsxjs197 code adaptations.

3rd party Wii Classic Controller and Pro extended support from RX 2.7 is retained, as well as PS1 / PS2 controller support through the 3rd party Wiimote adapter.

Experimental builds with PSX Multitap support also available. Compatible titles tested are included on a TXT inside the respective .zip

Find a growing list of new playable and tested games on the second post of the official WiiSXRX thread, here:
https://gbatemp.net/threads/wiisx-rx-a-new-fork.570252/


++ Beta 3.0 - 20220912:

Evo branch, lots of updates.

* Slow, progressive merge and update to xjsxjs197's WiiSXRX fork. Code updated until commit a03f618a895fb526bef35808a698dc52e0dbb4e1 (Aug 26, 2022).

* For now, discarded the "Languages" option, which tends to cause some minor random crashes on the UI, with certain actions.
* When you open a directory with CUE+BIN, only the CUE will be shown. This condition is only true if the CUE and BIN tracks contain the same name, i.e.: "Mortal Kombat Trilogy (USA)"
* CD-ROM plugin changed from CDR Mooby to CDR ISO (PCSX-df). Highly improved game compatibility, and Swap CD fix for many games.
* Keeping FranSPU sound plugin (psx4all) over the dfsound plugin (pcsxr), for the moment. This will give different compatibility/results on some titles when compared to the fork, and a tiny speedup.
* BIOS, MDEC decoder (FMV), R3000 CPU updates and fixes.

Thanks goes to the PCSX / PCSX-df / PCSX-r / PCSX-Revolution / PCSX-ReARMed teams, and xjsxjs197 code adaptations.

3rd party Wii Classic Controller and Pro extended support from RX 2.7 is retained, as well as PS1 / PS2 controller support through the 3rd party Wiimote adapter.

Experimental builds with PSX Multitap support also available. Compatible titles tested are included on a TXT inside the respective .zip

Find a growing list of new playable and tested games on the second post of the official WiiSXRX thread, here:
https://gbatemp.net/threads/wiisx-rx-a-new-fork.570252/


Beta 2.7 - 20220722:
* Update CDrom
Last minor update before changing around the compatibility.
Makes some extra games boot with BIOS without the need to use HLE exclusively.
(Resident Evil 2 - Dual Shock Ver., Pocket Fighter, etc.)
* The settings file is now named settingsRX.cfg, so other forks don't overwrite it.
You can rename you current settings.cfg or just quickly create a new one inside WiiSXRX.
* Readme updates

* Experimental builds with auto-enabled PSX Multitap support added. (thanks vmartinv!)
Tested compatible games are listed on a TXT inside the zipped file.
If it is not listed, then it's untested.

Beta 2.6:
* V-Sync is now activated. (thanks xjsxjs197!)
* Adjust some button shortcuts for entering the Menu.
Specially useful for people who use alternative classic controllers or
adapters that connect to the Wiimote, such as the DualShock 2, arcade
joysticks, NES and SNES Classic controllers, etc., some of which don't have
a Home button to return to the emulator's main menu.
* UStealth support.
* Wii 480p video fix. [Extrems]
* More 3rd party controllers support. [Tantric]
Fix 3rd party classic controllers that don't send calibration data.
For those controllers, use default values.

Beta 2.5:
* Version bump, IOS & CPU speed inside Credits.
* Controller settings SD saving bugfix.
* Increased analog value to cover the full range
on the Wii Classic Controller. [loquinator3000]
* Autoboot support for Wiiflow. (thanks Wiimpathy!)

Beta 2.4:
* Credits update.
* Corrected small analog to digital mistake in gamepad. [FIX94]
* Sort by name or type on the file list with WCC ZR.
* Fix error saving memory cards message. [emukidid]
* Increased GC analog value to cover the full 256 value range. [emukidid] 

Beta 2.3:
* Fix indentation issue.
* Missing include [Mystro256]
* Fix misleading indentation warnings.
* Fix missing stricmp. [Mystro256]
* Flag opt cleanup for new gcc. [Mystro256]
* Silence format warnings [Mystro256]
Should have no binary change.
* Silence warnings by making some functions static. [Mystro256]
* Remove statics in psxinterpreter to silence a warning. [Mystro256]
* Basic WiiU gamepad support in Wii VC using libwiidrc. [FIX94]
* Corrected bugs in button mapping. [FIX94]
* Make sure args exist before parsing them... [FIX94]
...and make sure stubhaxx exists
* Properly switched WUPC values, refined DRC analog stick... [FIX94]
...conversion and added comments to exit code.
* Adjusted DRC deadzone accordingly. [FIX94]
* Math is hard, didnt have enough coffee today for that. [FIX94]
* Credits update, and other minor QoL fixes.
* We have a neat savestates folder now.

Beta 2.2:
* New working directory on the root of the device, WiiSXRX.
* Fixed compile error with SMB.
* Rebranding to WiiSX RX.

OLD CHANGE LOG:
Beta 2.2:
   * Very minor speed tweaks (some games are smoother)
   * UStealth support
   * Fix crashes for a handful of games
   * Fix crash when quitting
   * Built on lastest devKitPro
   * Rebranding to WiiSXR

Beta 2.1 Mod 6 (Daxtsu):
   + LibWupc (support for WiiU Classic Controller Pro)

Beta 2.1 Mod 4 (matguitarist):
   + cIOS no longer required (official IOS58 required)

Beta 2.1 Mod 3 (matguitarist):
   + improved support for USB 2.0
   + support for both USB Port 0 and Port 1

Beta 2.1 Mod 2 (matguitarist):
   + support for USB 2.0

Beta 2.1:
   * Compiled with devkitPPC r21 / libOGC SVN
   * Compiled with new libDI / DVDx V2
   * Saving improvements
     * Fixed issues where save was not written to memcard
     + Audio state saved/loaded for save states
   * Controller improvements
     * Fixed inverted Y-axis on analog input
     * Fixed rumble
     * Fixed button presses on unused input port
     + Added “Home” button as a menu combo for CC
     + Added disable rumble setting
   * Network improvements
     * SMB correction to allow anonymous user and password
     + Threaded network init and proper error messages when it fails
Beta 2:
   * Compiled with devkitPPC r21 / libOGC SVN
   * Compiled with new libDI / DVDx V2
   * DVD reads are now done with direct PowerPC access
   + Samba loading
   + Execute BIOS
   * Controller improvements
     + Rumble for Wiimote-based input
     + Wiimote-only controls
     + Classic Controller Pro & 3rd party controller support
     + Reconfigurable button mapping
       + Save/Load button mapping from file
   + New menu system
     + Classic Controller support
     + Wiimote / Wiimote & nunchuck support
     + Settings saving
     + Auto load/save option for saves
   * PEOPS GPU
     + Pillar-boxing 'Force 16:9' mode
     * Fixed color mapping for FMV
   + FranSPU
     * Smooth stereo audio at full FPS
   - PEOPS SPU
   + SSSPSX input plugin
     + DualShock Controller support
     + Rumble support
     * Analog/Digital switching
   + CDRMooby
     * Improved compatibility
     * CDDA not implemented yet
Beta 1:
   * Working audio (choppy)
   * DVD loading
   * Software GFX with GX scaling
   * Saving to SD card
   * Text UI
   * Known Issues:
     * CDDA audio streaming is not implemented
     * XA audio fails at times
     * Final Fantasy VII crashes Dynarec
     * FPS limit not working at times
   
